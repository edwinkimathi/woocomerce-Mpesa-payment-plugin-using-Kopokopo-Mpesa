<?php
/**
 * Plugin Name: WooCommerce Kopokopo Payment Gateway
 * Description: Accept M-PESA payments via Kopokopo's STK Push API.
 * Version: 1.0
 * Author: Edwin Kimathi
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Check if WooCommerce is active.
function wc_kopokopo_check_woocommerce() {
    return class_exists('WooCommerce');
}

// Initialize the plugin only if WooCommerce is active.
function wc_kopokopo_init() {
    if (wc_kopokopo_check_woocommerce()) {
        // Include required files.
        require_once plugin_dir_path(__FILE__) . 'includes/class-kopokopo-gateway.php';
        require_once plugin_dir_path(__FILE__) . 'includes/class-kopokopo-webhook-handler.php';
        require_once plugin_dir_path(__FILE__) . 'includes/class-wc-kopokopo-blocks-integration.php';

        // Add the gateway to WooCommerce.
        add_filter('woocommerce_payment_gateways', function ($methods) {
            $methods[] = 'WC_KopoKopo_Full_Version';
            return $methods;
        });

    } else {
        // Display an admin notice if WooCommerce is not active.
        add_action('admin_notices', function () {
            echo '<div class="notice notice-error"><p>' .
                __('WooCommerce Kopokopo Payment Gateway requires WooCommerce to be installed and active.', 'woocommerce') .
                '</p></div>';
        });
    }
}
add_action('plugins_loaded', 'wc_kopokopo_init');