<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WC_KopoKopo_Full_Version extends WC_Payment_Gateway {

    public $client_id;
    public $client_secret;
    public $webhook_url;
    public $till_number;

    public function __construct() {
        $this->id                 = 'kopokopo';
        $this->method_title       = __( 'Kopokopo M-PESA', 'woocommerce' );
        $this->method_description = __( 'Accept payments via M-PESA using Kopokopo.', 'woocommerce' );
        $this->has_fields         = true;

        // Add block support.
        $this->supports = array(
            'products',
            'woocommerce_blocks',
        );

        // Load settings.
        $this->init_form_fields();
        $this->init_settings();

        // Initialize properties.
        $this->title         = $this->get_option( 'title' );
        $this->description   = $this->get_option( 'description' );
        $this->client_id     = $this->get_option( 'client_id' );
        $this->client_secret = $this->get_option( 'client_secret' );
        $this->webhook_url   = home_url( '/wc-api/kopokopo-webhook' );
        $this->till_number   = $this->get_option( 'till_number' );

        // Actions.
        add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
        add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );

        error_log( 'Kopokopo Gateway Initialized' );
    }

    public function init_form_fields() {
        $this->form_fields = array(
            'enabled' => array(
                'title'   => __( 'Enable/Disable', 'woocommerce' ),
                'type'    => 'checkbox',
                'label'   => __( 'Enable Kopokopo M-PESA', 'woocommerce' ),
                'default' => 'yes'
            ),
            'title' => array(
                'title'       => __( 'Title', 'woocommerce' ),
                'type'        => 'text',
                'description' => __( 'Payment method title.', 'woocommerce' ),
                'default'     => __( 'M-PESA', 'woocommerce' )
            ),
            'description' => array(
                'title'       => __( 'Description', 'woocommerce' ),
                'type'        => 'textarea',
                'description' => __( 'Description shown on checkout page.', 'woocommerce' ),
                'default'     => __( 'Pay securely using M-PESA.', 'woocommerce' )
            ),
            'client_id' => array(
                'title'       => __( 'Client ID', 'woocommerce' ),
                'type'        => 'text',
                'description' => __( 'Your Kopokopo Client ID.', 'woocommerce' )
            ),
            'client_secret' => array(
                'title'       => __( 'Client Secret', 'woocommerce' ),
                'type'        => 'password',
                'description' => __( 'Your Kopokopo Client Secret.', 'woocommerce' )
            ),
            'till_number' => array(
                'title'       => __( 'Till Number', 'woocommerce' ),
                'type'        => 'text',
                'description' => __( 'The M-PESA Till Number associated with your business.', 'woocommerce' ),
                'default'     => ''
            )
        );
    }

    public function is_available() {
        $available = parent::is_available();
        error_log( 'Kopokopo Gateway Availability: ' . ( $available ? 'Yes' : 'No' ) );
        return $available;
    }

    public function process_payment( $order_id ) {
        $order = wc_get_order( $order_id );
        $phone = $order->get_meta( 'billing_phone' );

        if ( empty( $phone ) ) {
            wc_add_notice( __( 'Please provide a valid M-PESA phone No.', 'woocommerce' ), 'error' );
            return;
        }

        $response = $this->send_stk_push( $order, $phone );

        if ( $response['success'] ) {
            $order->update_status( 'on-hold', __( 'Awaiting M-PESA payment.', 'woocommerce' ) );
            return array(
                'result'   => 'success',
                'redirect' => $this->get_return_url( $order )
            );
        } else {
            wc_add_notice( __( 'Error processing payment.', 'woocommerce' ), 'error' );
            return;
        }
    }

    private function send_stk_push( $order, $phone ) {
        try {
            $amount    = $order->get_total();
            $reference = 'Order#' . $order->get_id();
            $token     = $this->get_access_token();

            $data = array(
                'source'          => 'customer',
                'destination'     => 'business',
                'payment_channel' => 'MPESA_STK_PUSH',
                'till_number'     => $this->till_number,
                'phone_number'    => $phone,
                'amount'          => $amount,
                'currency'        => 'KES',
                'callback_url'    => $this->webhook_url,
                'metadata'        => array(
                    'reference' => $reference,
                    'order_id'  => $order->get_id()
                )
            );

            $response = wp_remote_post( 'https://api.kopokopo.com/api/v1/incoming_payments', array(
                'headers' => array(
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json'
                ),
                'body' => json_encode( $data )
            ) );

            if ( is_wp_error( $response ) ) {
                return array( 'success' => false, 'message' => 'API error' );
            }

            $body = json_decode( wp_remote_retrieve_body( $response ), true );
            return array( 'success' => true, 'data' => $body );
        } catch ( Exception $e ) {
            return array( 'success' => false, 'message' => $e->getMessage() );
        }
    }

    private function get_access_token() {
        $response = wp_remote_post( 'https://app.kopokopo.com/oauth/token', array(
            'body' => array(
                'grant_type'    => 'client_credentials',
                'client_id'     => $this->client_id,
                'client_secret' => $this->client_secret
            )
        ) );

        if ( is_wp_error( $response ) ) {
            throw new Exception( 'Failed to get access token.' );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        return $body['access_token'];
    }

    public function thankyou_page( $order_id ) {
        echo '<p>' . __( 'Thank you for your order. Please complete the M-PESA payment.', 'woocommerce' ) . '</p>';
    }
}
