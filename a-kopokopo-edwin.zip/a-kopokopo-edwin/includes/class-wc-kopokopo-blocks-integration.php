<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Initialize WooCommerce Blocks integration when Blocks are loaded.
 */
function kopokopo_init_blocks_integration() {
    // Check if the required WooCommerce Blocks class exists.
    if ( ! class_exists( 'Automattic\WooCommerce\Blocks\Payments\AbstractPaymentMethodType' ) ) {
         error_log('[Kopokopo Blocks] WooCommerce Blocks class not available at init.');
         return;
    }
    
    error_log('[Kopokopo Blocks] WooCommerce Blocks class is available. Initializing Blocks Integration.');

    // Define our Blocks Payment Method class.
    class WC_KopoKopo_Blocks_Payment_Method extends Automattic\WooCommerce\Blocks\Payments\AbstractPaymentMethodType {
        public function get_name() {
            error_log('[Kopokopo Blocks] get_name() called.');
            return 'kopokopo';
        }
        public function get_title() {
            error_log('[Kopokopo Blocks] get_title() called.');
            return __( 'M-Pesa', 'kopokopo' );
        }
        public function get_description() {
            error_log('[Kopokopo Blocks] get_description() called.');
            return __( 'Pay via M-Pesa using Kopokopo.', 'kopokopo' );
        }
        public function get_payment_method_script_handles() {
            error_log('[Kopokopo Blocks] get_payment_method_script_handles() called.');
            $handles = array( 'kopokopo-blocks-checkout' );
            error_log('[Kopokopo Blocks] Script handles: ' . print_r( $handles, true ));
            return $handles;
        }
        public function is_active() {
            error_log('[Kopokopo Blocks] is_active() called.');
            return true;
        }
        public function get_icon() {
            error_log('[Kopokopo Blocks] get_icon() called.');
            return null;
        }
    }

    // Define the integration class that enqueues assets and registers the payment method.
    class WC_KopoKopo_Blocks_Integration {
        public function __construct() {
            error_log('[Kopokopo Blocks] WC_KopoKopo_Blocks_Integration constructor called.');
            add_action( 'enqueue_block_editor_assets', array( $this, 'enqueue_assets' ) );
            add_action( 'woocommerce_blocks_payment_method_type_registration', array( $this, 'register_payment_method' ) );
        }
        public function enqueue_assets() {
            error_log('[Kopokopo Blocks] enqueue_assets() called.');
            $script_url  = plugin_dir_url( __FILE__ ) . 'blocks-checkout.js';
            $script_path = plugin_dir_path( __FILE__ ) . 'blocks-checkout.js';
            if ( ! file_exists( $script_path ) ) {
                error_log('[Kopokopo Blocks] blocks-checkout.js not found at: ' . $script_path );
            } else {
                error_log('[Kopokopo Blocks] blocks-checkout.js found.');
            }
            wp_enqueue_script(
                'kopokopo-blocks-checkout',
                $script_url,
                array( 'wp-element', 'wp-data', 'wp-i18n', 'wc-blocks-checkout' ),
                filemtime( $script_path ),
                true
            );
        }
        public function register_payment_method( $registry ) {
            error_log('[Kopokopo Blocks] register_payment_method() called.');
            if ( class_exists( 'WC_KopoKopo_Blocks_Payment_Method' ) ) {
                error_log('[Kopokopo Blocks] WC_KopoKopo_Blocks_Payment_Method exists. Registering...');
                $registry->register( new WC_KopoKopo_Blocks_Payment_Method() );
            } else {
                error_log('[Kopokopo Blocks] WC_KopoKopo_Blocks_Payment_Method does not exist.');
            }
        }
    }

    new WC_KopoKopo_Blocks_Integration();
}
//add_action('plugins_loaded', 'kopokopo_init_blocks_integration', 20);
add_action('woocommerce_blocks_loaded', function() {
    if (class_exists('Automattic\WooCommerce\Blocks\Payments\AbstractPaymentMethodType')) {
        error_log('WooCommerce Blocks is now available!');
        kopokopo_init_blocks_integration();
    } else {
        error_log('WooCommerce Blocks is still missing.');
    }
});

