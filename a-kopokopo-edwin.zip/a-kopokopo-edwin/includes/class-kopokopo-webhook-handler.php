<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Kopokopo_Webhook_Handler {

    public function __construct() {
        add_action( 'wp_ajax_nopriv_kopokopo_webhook', array( $this, 'handle_webhook' ) );
    }

    public function handle_webhook() {
        $payload = json_decode( file_get_contents( 'php://input' ), true );

        if ( ! $this->validate_webhook( $payload ) ) {
            wp_send_json_error( 'Invalid webhook signature' );
        }

        $reference = $payload['data']['attributes']['metadata']['reference'] ?? '';
        $status    = $payload['data']['attributes']['status'];

        if ( strpos( $reference, 'Order#' ) === 0 ) {
            $order_id = str_replace( 'Order#', '', $reference );
            $order    = wc_get_order( $order_id );

            if ( $status === 'complete' ) {
                $order->payment_complete();
            } elseif ( $status === 'failed' ) {
                $order->update_status( 'failed', __( 'M-PESA payment failed.', 'woocommerce' ) );
            }
        }

        wp_send_json_success( 'Webhook processed successfully' );
    }

    private function validate_webhook( $payload ) {
        // Implement webhook validation logic here.
        return true;
    }
}

new Kopokopo_Webhook_Handler();
