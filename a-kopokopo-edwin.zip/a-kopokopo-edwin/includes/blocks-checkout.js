const { registerPaymentMethod } = wc.wcBlocksRegistry;
const { __ } = wp.i18n;
const { createElement } = wp.element;

// Define the payment method component
const KopoKopoComponent = (props) => {
    return createElement(
        'div',
        null,
        __('Pay securely via M-Pesa using Kopokopo.', 'kopokopo')
    );
};

// Register the payment method for block-based checkout.
registerPaymentMethod({
    name: 'kopokopo_full_version',
    label: __('M-Pesa', 'kopokopo'),
    ariaLabel: __('Pay via M-Pesa using Kopokopo', 'kopokopo'),
    content: createElement(KopoKopoComponent),
    edit: createElement(KopoKopoComponent),
    canMakePayment: () => true,
    supports: {
        showSavedCards: false,
    }
});
